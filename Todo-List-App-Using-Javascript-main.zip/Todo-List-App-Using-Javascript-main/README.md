# Todo-List-App

User can add, check after completed and delete a particular task.

User can delete the task by clicking on the delete icon.

View of the Todo List App...

## You can visit: https://todolistninjas.netlify.app/


![todo screenshot](https://user-images.githubusercontent.com/18380165/213927289-dccd5e45-88cc-4dd9-8ea9-72fcc8f00c01.jpg)
